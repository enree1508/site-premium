# Site Premium Locação

Site institucional da Premium Locação de Guindastes e Transportes.

## Conteúdo
- `index.html` — o site inteiro (textos, estilo e animações em um só arquivo)
- `m/` e `n/` — fotos e vídeos usados no site

## Como colocar no ar pelo GitHub Pages
1. Crie um repositório novo no GitHub (por exemplo, `site-premium`).
2. Envie todos os arquivos desta pasta para a raiz do repositório, mantendo as pastas `m` e `n`.
3. No repositório, vá em **Settings > Pages**.
4. Em **Source**, escolha **Deploy from a branch**, selecione a branch `main` e a pasta `/ (root)`. Salve.
5. Em alguns minutos o endereço aparece na própria página (algo como `https://SEU-USUARIO.github.io/site-premium/`).

Para usar o domínio próprio (premiumlocacao.com.br), em **Settings > Pages > Custom domain** informe o domínio e aponte o DNS para o GitHub Pages.

## Observações
- O site não precisa de servidor nem de banco de dados: é só abrir o `index.html`.
- As letras vêm do Google Fonts (Source Sans Pro) e precisam de internet.
- O formulário de contato abre o WhatsApp da Premium: (98) 9 9171-1704.
